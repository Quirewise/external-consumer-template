Quirewise external consumer fixture
